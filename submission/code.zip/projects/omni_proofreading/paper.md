# Eleven exactly certified violations of the proofreading bound $e^{-2\Delta}$ among 88 two-bound-state networks

Colin Ji, Laurenz Thümmler, Noah Schittenhelm, Ali Suleman, ETH Zürich, Switzerland

# Eleven exactly certified violations of the proofreading bound $e^{-2\Delta}$ among 88 two-bound-state networks

*Author: alizema700@gmail.com*

## Abstract

We ask whether the Hopfield error bound of kinetic proofreading holds universally for Markov networks with two bound states and fuel-driven steps. For the linear Hopfield chain with $n=2$, $\eta \geq e^{-3\Delta}$ is proved for all positive rates and fuel potentials by a symbolic coefficient-positivity argument [C-proofreading-R9]. The enumerated family has 88 admissible members [C-fakt-familie]. For 50 of them, $\eta \geq e^{-2\Delta}$ is proved symbolically; 11 have exact rational-arithmetic certificates of violation, with $\eta$ down to 1.386398e-12; 27 remain open [C-fakt-klassifikation] [C-fakt-verletzungen-eta]. Hence $e^{-2\Delta}$ is violated by 11 of these networks [C-fakt-klassifikation]. The classification is computer-assisted: the bounds are symbolic, and the violations are exact rational certificates at specific rates. Whether the 27 open members obey the bound, and which structural feature causes violations, remains open [C-fakt-klassifikation].

## Introduction

Kinetic proofreading increases specificity beyond what free-energy differences or kinetic barriers alone allow, if the reaction is strongly but nonspecifically driven [C-lit8]. The ultimate accuracy of error-correcting pathways is set by the displacement from equilibrium of the driving nucleoside triphosphates [C-lit3]. Several checking steps reach a given accuracy at lower dissipation than a single step [C-lit4]. Pareto fronts for energy-relay proofreading yield trade-off relations and scaling laws [C-lit1], and a dynamical phase transition has been reported in the mixed regime [C-lit2]. In the generalized Hopfield model, more proofreading steps give better trade-offs [C-lit12], and the scaling relations were studied numerically [C-lit13]. A kinetically controlled bound on error for proofreading networks has been derived [C-lit10], and experimental systems have been compared with it [C-lit11]. Asymptotic scaling analyses of arbitrary networks, inspired by Hopfield's treatment, have also been given [C-lit24].

The open question is whether the Hopfield bound $\eta \geq e^{-(n+1)\Delta}$ is a universal limit for all networks with a fixed number of bound states, or whether topologies with fuel-driven discard pathways break it. The question is hard because the topology space is combinatorial and the rate space is high-dimensional, and numerical optima cannot establish a bound. A lower bound must hold for all rates. A violation must be exact, which excludes rounding artefacts. We therefore pair symbolic positivity proofs for bounds with exact rational certificates for violations.

**Summary of results.**

- Theorem 1 shows that the family with two bound states has 88 admissible members, of which 50 obey $\eta \geq e^{-2\Delta}$, 11 have certified violations and 27 are open [C-fakt-klassifikation] [C-fakt-familie].
- Theorem 2 shows an exactly certified violation for fam2_66, with $\eta = 5.082802$e-07 [C-proofreading-R4] [C-fakt-fam66].
- Theorem 3 shows two further exact violations, fam2_9 and fam2_11 [C-proofreading-R12].
- Theorem 4 shows exact violations for 10 topologies jointly, which adds eight to those of Theorem 3 [C-proofreading-O14].
- The Hopfield-chain theorem shows that $\eta \geq e^{-3\Delta}$ holds for the chain with $n=2$ for all positive rates and fuel potentials [C-proofreading-R9].
- The 50-topology theorem shows that $\eta \geq 1/D^2$ is proved symbolically for 50 topologies of the family, where $1/D^2$ is the bound $e^{-2\Delta}$ of the classification [C-proofreading-R11] [C-fakt-klassifikation].

## Setting

All parameters are fixed by the model [C-modell]. The discrimination free-energy difference is $\Delta = \ln 100$, so $e^{\Delta} = 100$ and $e^{-\Delta} = 0.01$ [C-modell]. The wrong substrate W leaves bound states $e^{\Delta}$ times faster than the right substrate R [C-modell]. Both substrates traverse the same Markov network, every edge has a reverse edge, and local detailed balance holds. Cycle affinities arise only from the fuel potential $\mu \geq 0$ per fuel-driven activation and $\mu_P \geq 0$ per product, both explored in $[0,20]$ [C-modell]. Concentrations are absorbed into the binding rates. All rates, including derived reverse rates, lie in $[e^{-L}, e^{L}]$ with $L = 10$ [C-modell]. A network has at most 10 states (unbound states plus R and W copies of bound states) [C-modell]. Rates are rounded to rationals with denominator at most $10^6$ for exact certificates [C-modell]. The enumerated family has $k=2$ bound states [C-modell].

Observables are the error rate $\eta = J_W/J_R$, the dissipation $\sigma$ (entropy production per product, in $kT$), and the speed $v = J_R$. We write $D = e^{\Delta}$ and $G = e^{\mu}$ [C-proofreading-R9]. The bound $1/D^2$ of the proved family is the bound $e^{-2\Delta}$ of the classification [C-proofreading-R11] [C-fakt-klassifikation].

 Four are degenerate (no net production possible, $\eta = 0/0$) and are excluded, leaving 88 [C-fakt-familie]. Two certificate types are used:

- **(a)** exact reachability: rational rates satisfying all constraints with the stated inequalities;
- **(b)** symbolic: $\eta - B = N/D$ with all coefficients of $N$ and $D$ nonnegative, which proves $\eta \geq B$ for all positive rates [C-proofreading-R9].

## Classification and certified violations

::: theorem [Classification of the two-bound-state family]
 The bound $e^{-2\Delta}$ is therefore violated by these 11 networks [C-fakt-klassifikation].
:::

*Certificate.* The counts were recomputed from the confirmed claims by the classification script. The counts 50, 11 and 27 sum to the family size of 88 [C-fakt-klassifikation] [C-fakt-familie].  Novelty status: not found in the literature search for the classification and the counterexamples [C-fakt-neuheit].

::: theorem [Violation in fam2_66]
For the topology fam2_66 there exist rational rates in $[e^{-10}, e^{10}]$ satisfying local detailed balance such that simultaneously $\eta \leq 0.0001$ and $v \geq 0.0001$ [C-proofreading-R4].
:::

*Certificate.* The topology has binding to C0, a fuel-driven conversion C0 to C1, a fuel-driven discard from C1, and product formation from C1. Exact reachability (a) gives $\eta = 5.082802$e-07, $\sigma = 8.341626\,kT$ per product and $v = 1.4746$e-03 [C-proofreading-R4] [C-fakt-fam66]. Novelty status: not found in a targeted search of 48 abstracts on 2026-10-04 [C-proofreading-R4].

::: theorem [Violations in fam2_11 and fam2_9]
For each of the two topologies fam2_11 and fam2_9 there exist rational rates in $[e^{-10}, e^{10}]$ satisfying local detailed balance with $\eta \leq 0.0001$ [C-proofreading-R12].
:::

*Certificate.* Certificate (a), checked in exact arithmetic for each case, passed for 2/2 cases [C-proofreading-R12]. Novelty status: not found in a targeted search of 42 abstracts on 2026-10-04 [C-proofreading-R12].

::: theorem [Further violations]
For each of the 10 topologies fam2_11, fam2_35, fam2_39, fam2_41, fam2_43, fam2_45, fam2_58, fam2_67, fam2_75 and fam2_9 there exist rational rates in $[e^{-10}, e^{10}]$ satisfying local detailed balance with $\eta \leq 0.0001$ [C-proofreading-O14].
:::

*Certificate.* Certificate (a) was checked exactly for each case and passed for 10/10 cases [C-proofreading-O14]. Two of these, fam2_9 and fam2_11, are already covered by the preceding theorem [C-proofreading-R12]. Novelty status: not checked [C-proofreading-O14].

The table lists the exact error rates of the certified violations. All are strictly below $e^{-2\Delta} = $ 1e-4 [C-fakt-verletzungen-eta].

Table: Exact error rates of the certified violations (rational rates, exact arithmetic) [C-fakt-verletzungen-eta].

| Topology | $\eta$ (exact) | Source |
|---|---|---|
| fam2_9 | 2.000856e-05 | proofreading-R12 [C-fakt-verletzungen-eta] |
| fam2_11 | 4.417288e-05 | proofreading-R12 [C-fakt-verletzungen-eta] |
| fam2_35 | 1.074798e-06 | proofreading-O14 [C-fakt-verletzungen-eta] |
| fam2_39 | 1.010274e-06 | proofreading-O14 [C-fakt-verletzungen-eta] |
| fam2_41 | 1.287193e-06 | proofreading-O14 [C-fakt-verletzungen-eta] |
| fam2_43 | 1.386398e-12 | proofreading-O14 [C-fakt-verletzungen-eta] |
| fam2_45 | 1.591024e-06 | proofreading-O14 [C-fakt-verletzungen-eta] |
| fam2_58 | 7.272608e-08 | proofreading-O14 [C-fakt-verletzungen-eta] |
| fam2_66 | 5.082802e-07 | proofreading-R4 [C-fakt-verletzungen-eta] |
| fam2_67 | 4.098578e-07 | proofreading-O14 [C-fakt-verletzungen-eta] |
| fam2_75 | 1.142234e-06 | proofreading-O14 [C-fakt-verletzungen-eta] |

::: remark [Status of the computer-assisted parts]
All statements in this article are computer-assisted. Type-(a) certificates rest on exact rational arithmetic with rates rounded to rationals of bounded denominator [C-modell]. Type-(b) certificates rest on exact symbolic expansion and a check that all coefficients are nonnegative [C-proofreading-R9]. The trusted base is the domain verifier, which passes its self-test with 18 of 18 cases (true, false, boundary and rule-violating cases) [C-fakt-selbsttest]. The numerical optimiser that finds candidate rates is not part of the trusted base, since only the exact check of the returned rationals counts. A third party re-runs every certificate with `python -m asd.recheck proofreading` and rebuilds the paper with `python -m asd.paper --domain proofreading` [C-verfuegbarkeit].
:::

## Proved bounds

::: theorem [Hopfield bound for the chain with $n=2$]
For the linear Hopfield chain hopfield_n2, $\eta \geq e^{-3\Delta}$ holds for all positive rates and all fuel potentials $\mu, \mu_P \geq 0$ (with $D = e^{\Delta}$, $G = e^{\mu}$) [C-proofreading-R9].
:::

*Proof.* Symbolic positivity (certificate (b)): $\eta - e^{-3\Delta} = N/D$ with $N$ and $D$ having 1374 and 2048 terms respectively, and all coefficients nonnegative (check returned True in 6.8 s) [C-proofreading-R9]. The proof is independent of the rate range [C-proofreading-R9]. Novelty status: not found in a targeted search of 40 abstracts on 2026-10-04 [C-proofreading-R9]. The novelty check classifies the chain bound as a reproduction of the Hopfield bound, treated here rigorously [C-fakt-neuheit].

::: theorem [Proved bound for 50 topologies]
For 50 topologies of the verifier-generated family with at most two bound states (one unbound state, edge catalogue of the model), $\eta \geq 1/D^2$ holds for all positive rates and fuel potentials [C-proofreading-R11]. This is the bound $e^{-2\Delta}$ of the classification [C-fakt-klassifikation].
:::

*Proof.* Symbolic certificate (b), with the bound proved for 50/50 members of the complete list [C-proofreading-R11]. Novelty status: not found in a targeted search of 48 abstracts on 2026-10-04 [C-proofreading-R11].

## Supporting statements and examples

::: proposition [Smaller sublists]
For 3 topologies of the verifier-generated family with at most two bound states, $\eta \geq 1/D^2$ holds for all positive rates and fuel potentials (certificate (b), symbolic) [C-proofreading-R6] [C-proofreading-R7].
:::

*Proof.* Symbolic certificate (b), 3/3 members proved, once for the largest justified sublist and once for the question whether going below $e^{-2\Delta}$ requires a fuel-driven discard exit at the product state [C-proofreading-R6] [C-proofreading-R7]. Novelty status: not found in targeted searches of 41 and 35 abstracts respectively on 2026-10-04 [C-proofreading-R6] [C-proofreading-R7]. Both lists are superseded by the 50-topology theorem [C-proofreading-R11].

::: proposition [Consistency of the count]
For 50 topologies of the verifier-generated family, $\eta \geq 1/D^2$ holds for all positive rates and fuel potentials (certificate (b), symbolic), consistent with the classification [C-proofreading-O15] [C-fakt-klassifikation].
:::

*Proof.* The certificate proved the bound for 50/50 members [C-proofreading-O15]. Novelty status: not checked [C-proofreading-O15].

The following exact points of the one-stage Hopfield chain (hopfield_n1) are certificates (a) of exact reachability. They are existence statements, not bounds.

::: example [Reachability at moderate dissipation]
For hopfield_n1 there exist rational rates in $[e^{-10}, e^{10}]$ satisfying local detailed balance with simultaneously $\eta \leq 0.0004$, $\sigma \leq 6.0\,kT$ per product and $v \geq 0.001$ [C-proofreading-R1].
:::

*Certificate.* Exact rational reachability check gives $\eta = 3.650169$e-04, $\sigma = 6.000000\,kT$, $v = 1.0417$e-01 [C-proofreading-R1]. Novelty status: not found in a targeted search of 62 abstracts on 2026-10-04 [C-proofreading-R1]. The novelty check classifies reachable points of the chain as qualitatively known, here exact [C-fakt-neuheit].

::: example [Reachability with $\eta \leq 0.01$]
For hopfield_n1 there exist rational rates in $[e^{-10}, e^{10}]$ satisfying local detailed balance with simultaneously $\eta \leq 0.01$ and $v \geq 0.001$ [C-proofreading-R3].
:::

*Certificate.* Exact rational reachability check gives $\eta = 5.909757$e-03, $\sigma = 3.998555\,kT$, $v = 7.1214$e-03 [C-proofreading-R3]. Novelty status: not found in a targeted search of 45 abstracts on 2026-10-04 [C-proofreading-R3].

::: example [Reachability at very low dissipation]
For hopfield_n1 there exist rational rates in $[e^{-10}, e^{10}]$ satisfying local detailed balance with simultaneously $\eta \leq 0.00012$ and $\sigma \leq 0.2\,kT$ per product [C-proofreading-R8].
:::

*Certificate.* Exact rational reachability check gives $\eta = 1.095823$e-04, $\sigma = 0.006292\,kT$, $v = 9.1487$e-09 [C-proofreading-R8]. The speed at this point is very small. Novelty status: not found in a targeted search of 49 abstracts on 2026-10-04 [C-proofreading-R8].

::: example [Reachability with a speed floor]
For hopfield_n1 there exist rational rates in $[e^{-10}, e^{10}]$ satisfying local detailed balance with simultaneously $\eta \leq 0.0002$, $\sigma \leq 10\,kT$ per product and $v \geq 0.001$ [C-proofreading-R10].
:::

*Certificate.* Exact rational reachability check gives $\eta = 1.189200$e-04, $\sigma = 4.271813\,kT$, $v = 1.0000$e-03 [C-proofreading-R10]. Novelty status: not found in a targeted search of 37 abstracts on 2026-10-04 [C-proofreading-R10].

## Discussion

The chain bound is the Hopfield bound for two proofreading stages, proved for all positive rates [C-proofreading-R9]. The classification shows that the corresponding statement for $e^{-2\Delta}$ fails for 11 members of the family with two bound states [C-fakt-klassifikation]. Fam2_66 has a fuel-driven discard from C1 and exhibits a violation [C-fakt-fam66]. We did not establish that such pathways are necessary, so this is an observation about one topology and not a criterion. The symbolic bound for all positive rates in the sublist question covers only 3 topologies [C-proofreading-R7].

The violations are exact existence statements at specific rational rates. They give no phase diagram and no information on the Pareto front of the violating networks. The operating points have high dissipation, for instance $\sigma = 8.341626\,kT$ per product at $v = 1.4746$e-03 for fam2_66 [C-fakt-fam66]. Whether such points are generic is not addressed. The 27 open members are neither proved nor refuted, so the classification is incomplete [C-fakt-klassifikation].

**What did not work.** First, the attempt to prove the bound for the sublist without a fuel-driven discard exit produced no verified claim, because of verifier errors that were fixed later [C-neg1]. Second, the search for further violations among the open topologies passed certificate (a) for all but one of the cases. The remaining case, fam2_13, failed because a rate left the allowed window ($|\log k| = 10.06$, derived reverse rates included) [C-neg2].

Open questions:

(i) What is the status of the 27 open topologies: does each obey $\eta \geq e^{-2\Delta}$ or violate it [C-fakt-klassifikation]?

(ii) Is there a structural criterion on the topology that separates the 50 proved members from the 11 violating ones [C-fakt-klassifikation]?

(iii) Does fam2_13 admit a violation with all rates, including derived reverse rates, inside $[e^{-10}, e^{10}]$ [C-neg2]?

## Declarations

**Affiliation** No institutional affiliation is given in the author line; contact: alizema700@gmail.com.

**Acknowledgements** Computations, literature searches and parts of the manuscript were prepared with an automated verifier-gated laboratory built on the AI system Claude (Anthropic). Every statement was accepted only after verification by code. The authors are responsible for the content.

**Code and data availability** Repository https://github.com/alizema700/Daddys-Project, branch claude/probatum-mcp, directory projects/omni_proofreading. All certificates are reproduced with `python -m asd.recheck proofreading`, and the paper is rebuilt with `python -m asd.paper --domain proofreading` [C-verfuegbarkeit].

**Competing interests** None.

## Appendix A: Numerical methods and error control

**Certificate types.** Type (a) fixes rational rates (denominator at most $10^6$) and evaluates $\eta$, $\sigma$ and $v$ exactly, so that the inequalities are checked without rounding [C-modell]. A rate outside $[e^{-10}, e^{10}]$ is rejected, including derived reverse rates [C-neg2]. Type (b) expands $\eta - B$ as $N/D$ and checks that all coefficients are nonnegative [C-proofreading-R9].

**Trusted base and self-test.** The verifier passes its self-test with 18 of 18 cases [C-fakt-selbsttest]. Re-running: `python -m asd.recheck proofreading` [C-verfuegbarkeit].

**Counter-checks as consistency tests.** A symbolic attempt to prove $\eta \geq 1.2\,e^{-2\Delta}$ at the claimed point of the low-dissipation example fails (137 and 167 terms, not all coefficients nonnegative) [C-proofreading-R8-RT1]. Attempts to prove the bound $1/D^2$ for the violating members fail (0/3 and 0/8 proved) [C-proofreading-R12-RT1] [C-proofreading-O14-RT1]. For the parameter set examined in the first reachability example, the same point remains admissible at larger dissipation budgets, which is incompatible with a reported jump of the front at that point [C-proofreading-R1-RT1]. An independent search for $n=2$ found $\eta_{\min} = 3.1387$e-05 at $\sigma = 2665.585$, not the lower value tested [C-proofreading-R9-RT2]. A further $n=2$ check gave $\eta = 4.879638$e-06 at $\sigma = 172.281249$ [C-proofreading-O15-RT3].

**Workflow.** The laboratory ran 16 rounds with 14 verified statements and 2 negative results, each round preregistered before the experiment [C-methode]. The preregistration (commit 6184672) preceded the first run, and later additions are dated [C-fakt-praereg]. The success criterion of at least 5 counterexamples in one round was missed: 2 were found in round 12, 3 in total [C-fakt-praereg]. Round 12 passed certificate (a) for 2/2 cases [C-fakt-r12]. The attempts on the discard-exit question were made by the agents sparsam/haiku, numeriker/haiku, skeptiker/sonnet and theoretiker/sonnet, and one further search by omnigent:researcher [C-neg1] [C-neg2].

**Literature search and red-team.** The search retrieved 2752 sources, screened 2502, and found 158 results with a code-confirmed verbatim quote; all 11 classic searches had hits [C-fakt-recherche]. Red-team counter-checks: 29 in total, 5 passed, 12 did not pass, 12 not executable [C-redteam]. The novelty statuses in the text come from targeted searches per result [C-neuheit-suche].

## Appendix B: Provenance of the statements

The provenance table mapping every statement to its evidence follows; it is generated automatically.
<!-- Abbildung pareto_front.pdf: Belege C-proofreading-R1, C-proofreading-R2, C-proofreading-R8, C-proofreading-R9, C-proofreading-R10, C-proofreading-O16 -->

<!-- Abbildung klassifikation.pdf: Belege C-proofreading-R4, C-proofreading-R6, C-proofreading-R7, C-proofreading-R11, C-proofreading-R12, C-proofreading-O14, C-proofreading-O15 -->

